Lietoto mantu sludinājumu dēlis (MySQL versija)


Kas nepieciešams

- PHP 8.1 vai jaunāks.
- MySQL vai MariaDB datubāze.
- PHP paplašinājums `pdo_mysql` (lai PHP varētu savienoties ar MySQL).
- PHP paplašinājums `fileinfo` (attēlu tipa pārbaudei).
- Serverim jāatļauj rakstīt mapē `storage/uploads/`.


1. Izveido tabulas datubāzē

1. Atver savu datubāzes pārvaldības vidi (piemēram, phpMyAdmin).
2. Izvēlies datubāzi, ko tev piešķīrusi skola/hostings. Ja tev vēl nav izveidota pati datubāze, vispirms izveido to vai palūdz skolotājam nosaukumu un piekļuves datus.
3. Atver cilni SQL.
4. Atver projekta failu `database/schema.sql`, nokopē visu tā saturu SQL laukā un palaid to.
5. Datubāzē jāparādās 3 tabulām: `market_users`, `market_listings`, `market_listing_images`.

SQL fails veido tabulas, bet nedzēš citas tabulas. Nosaukumiem ir prefikss `market_`, lai mazinātu iespēju nejauši konfliktēt ar citu projektu tabulām.

Ko katra tabula saglabā?

- `market_users` — konta vārdu, unikālu e-pastu, paroles jaucējvērtību, tālruni un izveides laiku.
- `market_listings` — sludinājuma autoru, nosaukumu, aprakstu, cenu centos, kategoriju, pārdošanas statusu un datumu.
- `market_listing_images` — attēlu failu nosaukumus un saiti uz konkrētu sludinājumu. Paši attēlu faili paliek servera mapē `storage/uploads/`; datubāzē neglabājam attēlu bināros datus.

2. Pievieno datubāzes pieslēguma datus

Atver projekta saknē esošo `config.php` un nomaini šīs vērtības uz skolas/hostinga piešķirtajām:

```php
return [
    'host' => 'localhost',
    'port' => 3308,
    'database' => 'DB_NOSAUKUMS',
    'username' => 'DB_LIETOTAJVĀRDS',
    'password' => 'DB_PAROLE',
];
```

4. Funkcionalitāte

- Reģistrācija, pieteikšanās un izrakstīšanās.
- Sludinājuma nosaukums, apraksts, cena un kategorija.
- Filtri pēc kategorijas un cenas, kārtošana pēc jaunuma/cenas.
- Sludinājuma atzīmēšana kā pārdotam; to drīkst darīt tikai sludinājuma autors.
- Līdz 4 JPEG/PNG/WEBP attēliem (katrs līdz 5 MB); attēlu atvēršana lielākā izmērā.
- Tālruņa numura maskēšana; pilnais numurs tiek nosūtīts tikai pieteikušamies lietotājam pēc pogas nospiešanas.
- Dati saglabājas MySQL. Attēlu faili tiek saglabāti servera diskā, un to nosaukumi ir DB.
- Servera puses validācija, CSRF marķieris formām, `password_hash()` paroles glabāšanai, PDO prepared statements SQL vaicājumiem un droša HTML izvade.

5. Projekta struktūra

```text
lietoto-mantu-sludinajumu-delis-mysql/
├── config.php                  # MySQL pieslēguma dati (jāaizpilda)
├── database/
│   └── schema.sql              # tabulu izveides SQL
├── public/                     # publiskā vietne - šo iestati kā servera web sakni
│   ├── index.php               # saskarne, formu apstrāde un programmas darbības
│   ├── image.php               # droša augšupielādēto attēlu izvadīšana
│   └── assets/
│       ├── app.js              # attēla palielināšana un tālruņa atklāšana
│       └── style.css           # vienkāršs lapas noformējums
├── src/
│   ├── bootstrap.php           # sesija, DB savienojums, drošības palīgfunkcijas
│   ├── MySQLStore.php          # MySQL nolasīšana un ierakstīšana
│   └── Validation.php          # validācijas noteikumi
├── storage/
│   └── uploads/                # attēlu faili (nedrīkst būt publiski izpildāmi)
├── tests/
│   └── validation_test.php     # automatizēti validācijas testi
├── DOKUMENTACIJA.md             # projekta un validācijas skaidrojums
└── README.md                    # šī palaišanas instrukcija
```


7. Biežākās problēmas

- Neizdodas pieslēgties datubāzei: vēlreiz pārbaudi host, DB nosaukumu, lietotāju, paroli un to, vai lietotājam ir atļauts pieslēgties no servera.
- `could not find driver`: PHP nav ieslēgts `pdo_mysql` paplašinājums.
- `Table doesn't exist`: SQL cilnē nav izpildīts `database/schema.sql` pareizajā datubāzē.
- Attēlu augšupielāde neizdodas: serverim nav rakstīšanas tiesību `storage/uploads/` mapē vai PHP augšupielādes limits ir mazāks par 5 MB.
- Tālrunis vai publicēšana prasa pieteikšanos: vispirms reģistrējies vai piesakies. Tas ir paredzētais sistēmas noteikums.

8. Izmantotie internetā pieejamie resursi

- PHP PDO prepared statements: https://www.php.net/manual/en/pdo.prepared-statements.php — izmantoti SQL vaicājumos, lai lietotāja ievadi nepievienotu pašam SQL tekstam.
- PHP PDO transactions: https://www.php.net/manual/en/pdo.transactions.php — izmantots transakciju princips, lai sludinājums un tā attēlu ieraksti datubāzē tiktu saglabāti kopā.
- PHP `password_hash()`: https://www.php.net/manual/en/function.password-hash.php — lietotāja parolei glabā jaucējvērtību, nevis atklātu paroli.
- MySQL foreign key constraints: https://dev.mysql.com/doc/refman/8.0/en/create-table-foreign-keys.html — `market_listings` sasaista autoru, bet `market_listing_images` sasaista attēlu metadatus ar sludinājumu.
- OWASP File Upload Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html — pielāgoti ieteikumi par attēlu tipa pārbaudi, izmēra robežu, nejaušu faila nosaukumu un atļauto failu tipu sarakstu.
