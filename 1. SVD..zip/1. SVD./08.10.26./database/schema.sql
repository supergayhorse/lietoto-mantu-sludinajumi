-- Lietoto mantu sludinājumu dēļa datubāzes struktūra.
-- Izvēlies savu jau izveidoto datubāzi phpMyAdmin, pēc tam atver SQL cilni un izpildi šo failu.
-- Tabulu nosaukumi sākas ar market_, lai nesakristu ar citu projektu tabulām.

CREATE TABLE IF NOT EXISTS market_users (
    id CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    name VARCHAR(40) NOT NULL,
    email VARCHAR(254) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL DEFAULT '',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_market_users_email (email),
    KEY idx_market_users_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS market_listings (
    id CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    user_id CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    title VARCHAR(80) NOT NULL,
    description VARCHAR(2000) NOT NULL,
    price_cents INT UNSIGNED NOT NULL,
    category VARCHAR(60) NOT NULL,
    sold TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_market_listings_user_id (user_id),
    KEY idx_market_listings_category_price (category, price_cents),
    KEY idx_market_listings_created_at (created_at),
    CONSTRAINT fk_market_listings_user
        FOREIGN KEY (user_id) REFERENCES market_users (id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_market_listing_price_positive CHECK (price_cents > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS market_listing_images (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    listing_id CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    file_name VARCHAR(40) NOT NULL,
    position_no TINYINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    UNIQUE KEY uq_market_image_file (file_name),
    KEY idx_market_listing_images_listing_id (listing_id),
    CONSTRAINT fk_market_listing_images_listing
        FOREIGN KEY (listing_id) REFERENCES market_listings (id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
