<?php

return [
    'host' => '153.92.1.116',          
    'port' => 3308,                 
    'database' => 'vb_sludinajumi',
    'username' => 'vevere_b',
    'password' => '0F}cv)Ma',
];