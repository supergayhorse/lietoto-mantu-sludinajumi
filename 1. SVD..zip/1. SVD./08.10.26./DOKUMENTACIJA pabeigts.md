Projekta dokumentācija — Lietoto mantu sludinājumu dēlis

1. Izvēlētā ideja

Izvēlēta projekta ideja ir 1.5. - Lietotu mantu sludinājumu dēlis. Programma paredzēta lietotu priekšmetu sludinājumu publicēšanai un pārlūkošanai.

Pamatfunkcijas: reģistrācija un pieteikšanās; sludinājuma nosaukums, apraksts, cena un kategorija; filtrēšana un kārtošana; pārdošanas statusa maiņa; attēlu augšupielāde un palielināta apskate; tālruņa numura maskēšana un atklāšana autorizētam lietotājam; MySQL datubāzes saglabāšana.

2. Programmas slāņi

Lietotāja saskarne ir `public/index.php`, `public/assets/style.css`, `public/assets/app.js`. HTML attēlo lapu un formas, CSS nodrošina vienkāršu noformējumu, JavaScript apstrādā tālruņa atklāšanas pieprasījumu un attēlu palielināšanu.

`public/index.php` apstrādā reģistrāciju, pieteikšanos, sludinājuma izveidi un statusa maiņu. `src/Validation.php` validē laukus.

`src/MySQLStore.php` lasa un raksta MySQL tabulas, izmantojot PDO. `database/schema.sql` izveido vajadzīgās tabulas un to saiknes.

`config.php` satur DB hostu, datubāzes nosaukumu, lietotājvārdu un paroli. Šis fails nav publiskajā `public/` mapē.

Paši attēli atrodas mapē `storage/uploads/`; datubāzē glabājas tikai faila nosaukums un piederība sludinājumam.


3. Datu bāzes struktūra

`market_users`


 `id` - Unikāls konta identifikators
 `name` - Vārds/lietotājvārds 
 `email` - Unikāla e-pasta adrese 
 `password_hash` - Paroles jaucējvērtība, nevis sākotnējā parole 
 `phone` - Normalizēts Latvijas tālruņa numurs vai tukša vērtība 
 `created_at` -  Konta izveides laiks 

`market_listings`

 `id` - Unikāls sludinājuma identifikators 
 `user_id` - Ārējā atslēga uz sludinājuma autoru 
 `title`, `description` | Sludinājuma teksts 
 `price_cents` - Cena centos kā veselais skaitlis (piemēram, 12,50 EUR ir 1250) 
 `category` - Kategorija no atļautā saraksta 
 `sold` - `0` — pieejams, `1` — pārdots 
 `created_at` - Publicēšanas laiks 

`market_listing_images`

Šajā tabulā glabājas katra attēla faila nosaukums, tā secība un `listing_id` ārējā atslēga. Attēli ir atsevišķi faili servera mapē, jo tas vienkāršo attēlu izvadīšanu un neuzpūš datubāzes ierakstus. Ārējās atslēgas palīz nepieļaut attēlu ierakstus vai sludinājumus, kuru saistītais objekts nav atrodams.

 4. Validācijas noteikumi un to pamatojums

Validācija ir gan HTML formās, gan PHP servera pusē. Pārlūka pārbaudes lietotājam uzreiz pasaka par vienkāršām kļūdām, bet servera pārbaudes atkārto noteikumus, jo klienta puses pārbaudes var apiet.


 Vārds | 2–40 rakstzīmes | `validate_registration()` failā `src/Validation.php` |
 E-pasts | Derīga e-pasta sintakse, ne vairāk par 254 baitiem; nedrīkst atkārtoties | `filter_var(..., FILTER_VALIDATE_EMAIL)`, unikāls DB indekss |
 Parole | Vismaz 8 un ne vairāk par 72 baitiem; atkārtotajai parolei jāsakrīt | `validate_registration()`; `password_hash()` reģistrācijā un `password_verify()` pieteikšanās laikā |
 Tālrunis | Latvijas numurs 2XXXXXXX (mobilais) vai 6XXXXXXX (fiksētais), ar vai bez +371; tiek noņemti atdalītāji | `normalise_latvian_phone()` |
 Nosaukums | 5–80 rakstzīmes | `validate_listing()` un HTML `minlength`/`maxlength` |
 Apraksts | 15–2000 rakstzīmes | `validate_listing()` un HTML `minlength`/`maxlength` |
 Kategorija | Atļauta tikai viena no `allowed_categories()` vērtībām | `in_array(..., true)` servera pusē |
 Cena | Pozitīva summa EUR ar tieši 2 decimālzīmēm, piemēram, `12.50`; glabā centos | `parse_listing_price()`; DB kolonna `price_cents` un `CHECK` ierobežojums atbalstītās MySQL versijās |
 Cenas filtrs | Atļauta tukša vērtība; ja norādīta, tai jābūt skaitliskai un saprātīgā formātā | `parse_optional_filter_price()` |
 Attēli | Ne vairāk par 4; JPEG, PNG vai WEBP; katrs ne vairāk par 5 MB; pārbauda faktisko MIME tipu un dimensijas | `store_uploaded_images()` failā `src/bootstrap.php` |
 Autorizācija | Tikai pieteicies lietotājs drīkst publicēt vai atklāt tālruni; tikai autors maina sava sludinājuma statusu | `require_login()`, sesija un autora ID pārbaude |
 SQL ievade | Lietotāja ievadi nepievieno tieši SQL vaicājuma tekstam | `PDO::prepare()` un parametri failā `src/MySQLStore.php` |
 HTML izvade | Lietotāja teksts tiek escapots pirms parādīšanas | `e()` izmanto `htmlspecialchars()` |
 Formu pieprasījumi | POST formām tiek pārbaudīts sesijas CSRF marķieris | `csrf_token()` un `verify_csrf_token()` |


5. Izvēlēto internetā pieejamo resursu pielietojums

1. PHP PDO prepared statement — https://www.php.net/manual/en/pdo.prepared-statements.php. Izmantots, lai sagatavotu datu ievietošanas un statusa maiņas SQL vaicājumus ar parametriem.
2. PHP PDO transactions — https://www.php.net/manual/en/pdo.transactions.php. Transakcija nodrošina, ka sludinājums un attēlu metadati tiek saglabāti kopā vai izmaiņas tiek atceltas kļūdas gadījumā.
3. PHP password_hash() — https://www.php.net/manual/en/function.password-hash.php. Izmantota iebūvētā paroļu jaucējvērtības funkcija; parole nav saglabāta atklātā formā.
4. MySQL ārējās atslēgas — https://dev.mysql.com/doc/refman/8.0/en/create-table-foreign-keys.html. Pielāgots tabulu dizains, lai norādītu saiknes starp lietotājiem, sludinājumiem un attēliem.
5. OWASP File Upload Cheat Sheet — https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html. Pielāgoti ieteikumi par atļautajiem attēlu tipiem, MIME pārbaudi, izmēra ierobežojumu un nejaušu faila nosaukumu.
6. HTML formu validācija (WHATWG) — https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#constraints. HTML formās izmantoti standarta validācijas atribūti; tās papildina, nevis aizstāj PHP servera validāciju.

6. Palaišana

1. Izveido MySQL/MariaDB datubāzi (to es izveidoju savā is-projekts-id).
2. Datubāzē izpildi failu `database/schema.sql'.
3. Ieraksti DB hostu, datubāzes nosaukumu, lietotājvārdu un paroli projekta saknes failā `config.php` (ievadīju savus datus).
4. Pārbaudi, ka serverī ir PHP 8.1+ ar `pdo_mysql` un `fileinfo` paplašinājumiem.
5. Lokāli palaid no projekta mapes `php -S 127.0.0.1:8000 -t public` un atver `http://127.0.0.1:8000`.
6. Reģistrējies, publicē testu sludinājumu, pārbaudi filtrus un atzīmē šo sludinājumu kā pārdotu.