<?php
declare(strict_types=1);

require_once __DIR__ . '/src/bootstrap.php';

/** Izvada vienkāršu JSON atbildi tālruņa atklāšanas pogai. */
function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ----- 1. FORMU APSTRĀDE (programmas loģika) -----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    $newlyUploadedImages = [];

    // Šī darbība notiek ar fetch() JavaScript pusē, tāpēc atgriežam JSON, nevis pāradresējam lapu.
    if ($action === 'reveal_phone') {
        try {
            verify_csrf_token();
            $viewer = require_login($store);
            $listingId = (string)($_POST['listing_id'] ?? '');
            $data = $store->read();

            $targetListing = null;
            foreach ($data['listings'] as $listing) {
                if (($listing['id'] ?? '') === $listingId) {
                    $targetListing = $listing;
                    break;
                }
            }

            if ($targetListing === null) {
                json_response(['ok' => false, 'message' => 'Sludinājums nav atrasts.'], 404);
            }

            $phone = '';
            foreach ($data['users'] as $owner) {
                if (($owner['id'] ?? '') === ($targetListing['user_id'] ?? '')) {
                    $phone = (string)($owner['phone'] ?? '');
                    break;
                }
            }

            if ($phone === '') {
                json_response(['ok' => false, 'message' => 'Pārdevējs nav norādījis tālruņa numuru.'], 404);
            }

            // Pilnais numurs netiek ievietots HTML kodā; to nosūta tikai pēc autorizēta POST pieprasījuma.
            json_response(['ok' => true, 'phone' => $phone]);
        } catch (ValidationException $exception) {
            json_response(['ok' => false, 'message' => $exception->getMessage()], 403);
        } catch (Throwable $exception) {
            error_log((string)$exception);
            json_response(['ok' => false, 'message' => 'Neizdevās parādīt tālruni. Mēģini vēlreiz.'], 500);
        }
    }

    try {
        verify_csrf_token();

        switch ($action) {
            case 'register':
                $registration = validate_registration($_POST);

                // Unikalitāti pārbaudām un lietotāju pievienojam vienā bloķētā datu atjauninājumā.
                $newUser = $store->update(function (array &$data) use ($registration): array {
                    foreach ($data['users'] as $existingUser) {
                        if (strtolower((string)$existingUser['email']) === $registration['email']) {
                            throw new ValidationException('Lietotājs ar šo e-pasta adresi jau ir reģistrēts.');
                        }
                    }

                    $user = [
                        'id' => bin2hex(random_bytes(12)),
                        'name' => $registration['name'],
                        'email' => $registration['email'],
                        'password_hash' => $registration['password_hash'],
                        'phone' => $registration['phone'],
                        'created_at' => date(DATE_ATOM),
                    ];
                    $data['users'][] = $user;
                    return $user;
                });

                // Pēc reģistrācijas lietotājs tiek pieslēgts automātiski.
                session_regenerate_id(true);
                $_SESSION['user_id'] = $newUser['id'];
                set_flash('success', 'Konts izveidots! Tagad vari publicēt sludinājumus.');
                redirect('index.php');

            case 'login':
                $email = strtolower(trim((string)($_POST['email'] ?? '')));
                $password = (string)($_POST['password'] ?? '');
                if (filter_var($email, FILTER_VALIDATE_EMAIL) === false || $password === '') {
                    throw new ValidationException('Ievadi derīgu e-pastu un paroli.');
                }

                $data = $store->read();
                $matchingUser = null;
                foreach ($data['users'] as $candidate) {
                    if (strtolower((string)$candidate['email']) === $email) {
                        $matchingUser = $candidate;
                        break;
                    }
                }

                // Vienāds paziņojums nepareizam e-pastam un parolei neatklāj, vai konts eksistē.
                if ($matchingUser === null || !password_verify($password, (string)$matchingUser['password_hash'])) {
                    throw new ValidationException('E-pasts vai parole nav pareiza.');
                }

                session_regenerate_id(true);
                $_SESSION['user_id'] = $matchingUser['id'];
                set_flash('success', 'Tu esi veiksmīgi pieteicies.');
                redirect('index.php');

            case 'logout':
                // Izrakstīšanās notiek ar POST un CSRF marķieri, nevis ar vienkāršu GET saiti.
                unset($_SESSION['user_id']);
                session_regenerate_id(true);
                set_flash('success', 'Tu esi izrakstījies no sistēmas.');
                redirect('index.php');

            case 'create_listing':
                $user = require_login($store);
                $listingFields = validate_listing($_POST);

                // Visus attēlus pārbaudām un saglabājam; neveiksmes gadījumā faili tiek iztīrīti.
                $newlyUploadedImages = store_uploaded_images(
                    $_FILES['images'] ?? [],
                    $store->uploadsDirectory()
                );

                $store->update(function (array &$data) use ($user, $listingFields, $newlyUploadedImages): void {
                    $data['listings'][] = [
                        'id' => bin2hex(random_bytes(12)),
                        'user_id' => $user['id'],
                        'title' => $listingFields['title'],
                        'description' => $listingFields['description'],
                        'price_cents' => $listingFields['price_cents'],
                        'category' => $listingFields['category'],
                        'images' => $newlyUploadedImages,
                        'sold' => false,
                        'created_at' => date(DATE_ATOM),
                    ];
                });

                set_flash('success', 'Sludinājums ir publicēts!');
                redirect('index.php');

            case 'toggle_sold':
                $user = require_login($store);
                $listingId = (string)($_POST['listing_id'] ?? '');
                if ($listingId === '') {
                    throw new ValidationException('Trūkst sludinājuma identifikatora.');
                }

                $newSoldState = $store->update(function (array &$data) use ($listingId, $user): bool {
                    foreach ($data['listings'] as &$listing) {
                        if (($listing['id'] ?? '') === $listingId) {
                            // Tikai sludinājuma īpašnieks drīkst mainīt tā pārdošanas statusu.
                            if (($listing['user_id'] ?? '') !== $user['id']) {
                                throw new ValidationException('Mainīt sludinājuma statusu drīkst tikai tā autors.');
                            }
                            $listing['sold'] = !((bool)($listing['sold'] ?? false));
                            $newState = (bool)$listing['sold'];
                            unset($listing);
                            return $newState;
                        }
                    }
                    unset($listing);
                    throw new ValidationException('Sludinājums nav atrasts.');
                });

                set_flash('success', $newSoldState ? 'Sludinājums atzīmēts kā pārdots.' : 'Sludinājums atkal ir pieejams.');
                redirect('index.php');

            default:
                throw new ValidationException('Nezināma darbība.');
        }
    } catch (ValidationException $exception) {
        // Ja sludinājuma izveide neizdevās, izdzēšam šajā pieprasījumā augšupielādētos attēlus.
        foreach ($newlyUploadedImages as $imageName) {
            @unlink($store->uploadsDirectory() . DIRECTORY_SEPARATOR . $imageName);
        }
        set_flash('error', $exception->getMessage());
        redirect('index.php');
    } catch (Throwable $exception) {
        foreach ($newlyUploadedImages as $imageName) {
            @unlink($store->uploadsDirectory() . DIRECTORY_SEPARATOR . $imageName);
        }
        error_log((string)$exception);
        set_flash('error', 'Radās neparedzēta kļūda. Pārbaudi ievadītos datus un mēģini vēlreiz.');
        redirect('index.php');
    }
}

// ----- 2. DATU SAGATAVOŠANA SKATAM (lietotāja saskarne) -----
$user = current_user($store);
$data = $store->read();
$flash = take_flash();
$csrfToken = csrf_token();
$categories = allowed_categories();

// Meklēšanas laukiem validācija notiek arī servera pusē — GET parametrus nedrīkst akli uzticēties.
$filterError = '';
$selectedCategory = (string)($_GET['category'] ?? '');
if ($selectedCategory !== '' && !in_array($selectedCategory, $categories, true)) {
    $filterError = 'Nederīga kategorija filtrā.';
    $selectedCategory = '';
}

try {
    $minimumCents = parse_optional_filter_price((string)($_GET['min_price'] ?? ''));
    $maximumCents = parse_optional_filter_price((string)($_GET['max_price'] ?? ''));
} catch (ValidationException $exception) {
    $minimumCents = null;
    $maximumCents = null;
    $filterError = $exception->getMessage();
}

if ($minimumCents !== null && $maximumCents !== null && $minimumCents > $maximumCents) {
    $filterError = 'Minimālā cena nevar būt lielāka par maksimālo cenu.';
    $minimumCents = null;
    $maximumCents = null;
}

$sort = (string)($_GET['sort'] ?? 'newest');
if (!in_array($sort, ['newest', 'price_asc', 'price_desc'], true)) {
    $sort = 'newest';
}
$showOnlyMine = (string)($_GET['my'] ?? '') === '1' && $user !== null;

// Autoru vārdus glabājam atsevišķā masīvā, lai katrai kartītei nav jāpārmeklē lietotāju saraksts.
$userNames = [];
foreach ($data['users'] as $storedUser) {
    $userNames[$storedUser['id']] = $storedUser['name'];
}

$listings = array_values(array_filter($data['listings'], function (array $listing) use (
    $selectedCategory, $minimumCents, $maximumCents, $showOnlyMine, $user
): bool {
    if ($selectedCategory !== '' && ($listing['category'] ?? '') !== $selectedCategory) {
        return false;
    }
    if ($minimumCents !== null && (int)$listing['price_cents'] < $minimumCents) {
        return false;
    }
    if ($maximumCents !== null && (int)$listing['price_cents'] > $maximumCents) {
        return false;
    }
    if ($showOnlyMine && ($listing['user_id'] ?? '') !== $user['id']) {
        return false;
    }
    return true;
}));

// Kārtošanas režīms tiek izvēlēts tikai no atļautajām vērtībām.
usort($listings, static function (array $a, array $b) use ($sort): int {
    if ($sort === 'price_asc') {
        return ((int)$a['price_cents']) <=> ((int)$b['price_cents']);
    }
    if ($sort === 'price_desc') {
        return ((int)$b['price_cents']) <=> ((int)$a['price_cents']);
    }
    return strcmp((string)$b['created_at'], (string)$a['created_at']);
});

function image_url(string $fileName): string
{
    return 'image.php?file=' . rawurlencode($fileName);
}
?>
<!doctype html>
<html lang="lv">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= e($csrfToken) ?>">
    <title>Lietoto mantu sludinājumu dēlis</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/app.js" defer></script>
</head>
<body>
<header class="site-header">
    <div class="container header-row">
        <div>
            <p class="eyebrow">VIENKĀRŠS SLUDINĀJUMU PROTOTIPS</p>
            <h1><a href="index.php">Lietoto mantu dēlis</a></h1>
            <p class="subtitle">Atrodi lietotu mantu vai piedāvā savu nākamajam īpašniekam.</p>
        </div>
        <div class="account-box">
            <?php if ($user !== null): ?>
                <p>Sveiki, <strong><?= e($user['name']) ?></strong>!</p>
                <a class="text-link" href="index.php?my=1">Mani sludinājumi</a>
                <form action="index.php" method="post" class="inline-form">
                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                    <input type="hidden" name="action" value="logout">
                    <button class="button button-small button-light" type="submit">Izrakstīties</button>
                </form>
            <?php else: ?>
                <span class="muted">Pārlūko sludinājumus vai piesakies, lai publicētu savējo.</span>
            <?php endif; ?>
        </div>
    </div>
</header>

<main class="container main-content">
    <?php if ($flash !== null): ?>
        <div class="notice <?= e($flash['type'] === 'error' ? 'notice-error' : 'notice-success') ?>" role="status">
            <?= e($flash['message']) ?>
        </div>
    <?php endif; ?>

    <?php if ($user === null): ?>
        <section class="auth-grid" aria-label="Lietotāja konts">
            <article class="panel">
                <h2>Pieteikties</h2>
                <p class="muted">Ja tev jau ir konts, ievadi savus datus.</p>
                <form action="index.php" method="post" class="form-stack">
                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                    <input type="hidden" name="action" value="login">
                    <label for="login-email">E-pasts</label>
                    <input id="login-email" name="email" type="email" maxlength="254" autocomplete="email" required>
                    <label for="login-password">Parole</label>
                    <input id="login-password" name="password" type="password" autocomplete="current-password" required>
                    <button class="button" type="submit">Pieteikties</button>
                </form>
            </article>

            <article class="panel">
                <h2>Izveidot kontu</h2>
                <p class="muted">Konts vajadzīgs, lai publicētu sludinājumus un apskatītu pārdevēja tālruni.</p>
                <form action="index.php" method="post" class="form-stack">
                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                    <input type="hidden" name="action" value="register">
                    <label for="register-name">Vārds vai lietotājvārds</label>
                    <input id="register-name" name="name" type="text" minlength="2" maxlength="40" autocomplete="name" required>
                    <label for="register-email">E-pasts</label>
                    <input id="register-email" name="email" type="email" maxlength="254" autocomplete="email" required>
                    <label for="register-phone">Latvijas tālrunis (nav obligāts)</label>
                    <input id="register-phone" name="phone" type="tel" inputmode="tel" placeholder="+371 2XXXXXXX" pattern="(\+371[ ]?)?[26][0-9]{7}" title="Latvijas numurs: 2XXXXXXX vai 6XXXXXXX, ar vai bez +371" autocomplete="tel">
                    <label for="register-password">Parole (vismaz 8 rakstzīmes)</label>
                    <input id="register-password" name="password" type="password" minlength="8" maxlength="72" autocomplete="new-password" required>
                    <label for="register-password-repeat">Atkārto paroli</label>
                    <input id="register-password-repeat" name="password_repeat" type="password" minlength="8" maxlength="72" autocomplete="new-password" required>
                    <button class="button" type="submit">Reģistrēties</button>
                </form>
            </article>
        </section>
    <?php else: ?>
        <section class="panel publish-panel">
            <div class="section-heading">
                <div>
                    <h2>Publicēt jaunu sludinājumu</h2>
                    <p class="muted">Aizpildi laukus un, ja vēlies, pievieno līdz 4 attēliem.</p>
                </div>
            </div>
            <form action="index.php" method="post" enctype="multipart/form-data" class="form-stack">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                <input type="hidden" name="action" value="create_listing">
                <div class="form-grid">
                    <div>
                        <label for="listing-title">Nosaukums</label>
                        <input id="listing-title" name="title" type="text" minlength="5" maxlength="80" required placeholder="Piemēram, lietots velosipēds">
                    </div>
                    <div>
                        <label for="listing-price">Cena (EUR)</label>
                        <input id="listing-price" name="price" type="text" inputmode="decimal" pattern="[0-9]{1,7}[.,][0-9]{2}" title="Piemērs: 12.50" placeholder="12.50" required>
                    </div>
                    <div>
                        <label for="listing-category">Kategorija</label>
                        <select id="listing-category" name="category" required>
                            <option value="">Izvēlies kategoriju</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= e($category) ?>"><?= e($category) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="listing-images">Attēli (JPEG, PNG vai WEBP; līdz 5 MB katrs)</label>
                        <input id="listing-images" name="images[]" type="file" accept="image/jpeg,image/png,image/webp" multiple>
                    </div>
                </div>
                <div>
                    <label for="listing-description">Apraksts</label>
                    <textarea id="listing-description" name="description" rows="4" minlength="15" maxlength="2000" required placeholder="Apraksti priekšmeta stāvokli, izmēru un citu svarīgu informāciju."></textarea>
                </div>
                <p class="help-text">Cenai jābūt lielākai par 0,00 EUR. Attēli nav obligāti, bet sludinājumu ar attēliem ir vieglāk novērtēt.</p>
                <button class="button" type="submit">Publicēt sludinājumu</button>
            </form>
        </section>
    <?php endif; ?>

    <section class="listings-section" aria-labelledby="listings-heading">
        <div class="section-heading listings-heading-row">
            <div>
                <h2 id="listings-heading"><?= $showOnlyMine ? 'Mani sludinājumi' : 'Sludinājumi' ?></h2>
                <p class="muted">Atrasti sludinājumi: <?= count($listings) ?></p>
            </div>
            <?php if ($showOnlyMine): ?>
                <a class="text-link" href="index.php">Rādīt visus</a>
            <?php endif; ?>
        </div>

        <form method="get" action="index.php" class="filter-panel">
            <?php if ($showOnlyMine): ?><input type="hidden" name="my" value="1"><?php endif; ?>
            <div>
                <label for="filter-category">Kategorija</label>
                <select id="filter-category" name="category">
                    <option value="">Visas kategorijas</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= e($category) ?>" <?= $selectedCategory === $category ? 'selected' : '' ?>><?= e($category) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="filter-min">Cena no (EUR)</label>
                <input id="filter-min" name="min_price" type="text" inputmode="decimal" value="<?= e($_GET['min_price'] ?? '') ?>" placeholder="0.00">
            </div>
            <div>
                <label for="filter-max">Cena līdz (EUR)</label>
                <input id="filter-max" name="max_price" type="text" inputmode="decimal" value="<?= e($_GET['max_price'] ?? '') ?>" placeholder="100.00">
            </div>
            <div>
                <label for="filter-sort">Kārtot</label>
                <select id="filter-sort" name="sort">
                    <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Jaunākie vispirms</option>
                    <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Cena: no zemākās</option>
                    <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Cena: no augstākās</option>
                </select>
            </div>
            <div class="filter-actions">
                <button class="button" type="submit">Filtrēt</button>
                <a class="button button-light" href="<?= $showOnlyMine ? 'index.php?my=1' : 'index.php' ?>">Notīrīt</a>
            </div>
        </form>

        <?php if ($filterError !== ''): ?>
            <p class="inline-error" role="alert"><?= e($filterError) ?></p>
        <?php endif; ?>

        <?php if ($listings === []): ?>
            <div class="empty-state">
                <h3>Pašlaik nav neviena atbilstoša sludinājuma</h3>
                <p>Vari notīrīt filtrus vai pieslēgties un publicēt pirmo sludinājumu.</p>
            </div>
        <?php else: ?>
            <div class="listing-grid">
                <?php foreach ($listings as $listing): ?>
                    <?php
                    $isOwner = $user !== null && $user['id'] === ($listing['user_id'] ?? '');
                    $images = is_array($listing['images'] ?? null) ? $listing['images'] : [];
                    $authorName = $userNames[$listing['user_id'] ?? ''] ?? 'Nezināms lietotājs';
                    ?>
                    <article class="listing-card <?= !empty($listing['sold']) ? 'listing-sold' : '' ?>">
                        <?php if ($images !== []): ?>
                            <div class="listing-image-area">
                                <button type="button" class="image-open" data-full-image="<?= e(image_url((string)$images[0])) ?>" aria-label="Apskatīt attēlu lielākā izmērā">
                                    <img src="<?= e(image_url((string)$images[0])) ?>" alt="Sludinājuma attēls: <?= e($listing['title']) ?>" loading="lazy">
                                    <span class="image-hint">Apskatīt lielākā izmērā</span>
                                </button>
                                <?php if (count($images) > 1): ?>
                                    <div class="extra-images" aria-label="Pārējie attēli">
                                        <?php foreach (array_slice($images, 1) as $imageName): ?>
                                            <button type="button" class="image-open thumbnail-button" data-full-image="<?= e(image_url((string)$imageName)) ?>" aria-label="Atvērt papildu attēlu">
                                                <img src="<?= e(image_url((string)$imageName)) ?>" alt="Papildu attēls: <?= e($listing['title']) ?>" loading="lazy">
                                            </button>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="no-image" aria-label="Attēls nav pievienots">Attēls nav pievienots</div>
                        <?php endif; ?>

                        <div class="listing-card-body">
                            <div class="listing-title-row">
                                <h3><?= e($listing['title']) ?></h3>
                                <?php if (!empty($listing['sold'])): ?><span class="sold-label">Pārdots</span><?php endif; ?>
                            </div>
                            <p class="price"><?= e(format_price((int)$listing['price_cents'])) ?></p>
                            <p class="category-label"><?= e($listing['category']) ?></p>
                            <p class="description-text"><?= nl2br(e($listing['description'])) ?></p>
                            <div class="listing-meta">
                                <span>Pārdevējs: <?= e($authorName) ?></span>
                                <span><?= e(date('d.m.Y', strtotime((string)$listing['created_at']))) ?></span>
                            </div>

                            <?php if ($isOwner): ?>
                                <form action="index.php" method="post" class="owner-actions">
                                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                                    <input type="hidden" name="action" value="toggle_sold">
                                    <input type="hidden" name="listing_id" value="<?= e($listing['id']) ?>">
                                    <button class="button button-light button-small" type="submit">
                                        <?= !empty($listing['sold']) ? 'Atzīmēt kā pieejamu' : 'Atzīmēt kā pārdotu' ?>
                                    </button>
                                </form>
                            <?php else: ?>
                                <?php
                                $ownerPhone = '';
                                foreach ($data['users'] as $storedUser) {
                                    if (($storedUser['id'] ?? '') === ($listing['user_id'] ?? '')) {
                                        $ownerPhone = (string)($storedUser['phone'] ?? '');
                                        break;
                                    }
                                }
                                ?>
                                <?php if ($ownerPhone !== ''): ?>
                                    <div class="phone-row">
                                        <span class="phone-number"><?= e(mask_phone($ownerPhone)) ?></span>
                                        <?php if ($user !== null): ?>
                                            <button type="button" class="button button-small reveal-phone" data-listing-id="<?= e($listing['id']) ?>">Apskatīt tālruni</button>
                                        <?php else: ?>
                                            <span class="muted small-text">Piesakies, lai apskatītu</span>
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <p class="muted small-text">Pārdevējs nav norādījis tālruni.</p>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</main>

<footer class="site-footer">
    <div class="container">
        <p>Skolas projekta prototips · PHP, HTML, CSS un JavaScript · Dati tiek glabāti MySQL datubāzē.</p>
    </div>
</footer>

<!-- Vienkāršs modālais logs, kurā attēlu var apskatīt lielāku. -->
<dialog id="image-dialog" class="image-dialog" aria-label="Attēls lielākā izmērā">
    <button type="button" class="dialog-close" id="close-image-dialog" aria-label="Aizvērt attēlu">Aizvērt ✕</button>
    <img id="dialog-image" src="" alt="Palielināts sludinājuma attēls">
</dialog>
</body>
</html>
