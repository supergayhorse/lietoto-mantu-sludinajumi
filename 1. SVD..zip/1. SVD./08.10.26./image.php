<?php
declare(strict_types=1);

// Attēlus glabājam ārpus public mapes un izvadām caur šo skriptu.
// Faila nosaukumam jāatbilst mūsu pašu ģenerētajam nejaušajam formātam.
$fileName = (string)($_GET['file'] ?? '');
if (!preg_match('/^[a-f0-9]{32}\.(?:jpg|png|webp)$/', $fileName)) {
    http_response_code(404);
    exit('Attēls nav atrasts.');
}

$uploadDirectory = __DIR__ . '/storage/uploads';
$filePath = $uploadDirectory . DIRECTORY_SEPARATOR . $fileName;
if (!is_file($filePath)) {
    http_response_code(404);
    exit('Attēls nav atrasts.');
}

// Pirms nosūtīšanas vēlreiz pārbaudām faila saturu un pieļaujam tikai drošos attēlu tipus.
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime = $finfo->file($filePath);
$allowedMimes = ['image/jpeg', 'image/png', 'image/webp'];
if (!is_string($mime) || !in_array($mime, $allowedMimes, true)) {
    http_response_code(415);
    exit('Šī faila tips netiek atbalstīts.');
}

header('Content-Type: ' . $mime);
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=3600');
header('Content-Length: ' . (string)filesize($filePath));
readfile($filePath);
