<?php
declare(strict_types=1);

// Sesijas iestatījumi: sesijas sīkdatne nav pieejama JavaScript un tiek sūtīta tikai tajā pašā vietnē.
$isHttps = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => $isHttps,
    'httponly' => true,
    'samesite' => 'Lax',
]);
ini_set('session.use_strict_mode', '1');
session_start();

require_once __DIR__ . '/Validation.php';
require_once __DIR__ . '/MySQLStore.php';

// Konfigurācijas fails ir projekta saknē, ārpus publiskās public mapes.
$configFile = dirname(__DIR__) . '/config.php';
if (!is_file($configFile)) {
    http_response_code(500);
    exit('Nav atrasts config.php. Nokopē config.example.php uz config.php un ievadi datubāzes pieslēguma datus.');
}
$dbConfig = require $configFile;

try {
    // PDO izveido savienojumu ar MySQL. Kļūdas tiek izņēmumu veidā apstrādātas PHP kodā.
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        (string)($dbConfig['host'] ?? 'localhost'),
        (int)($dbConfig['port'] ?? 3306),
        (string)($dbConfig['database'] ?? '')
    );

    $pdo = new PDO($dsn, (string)($dbConfig['username'] ?? ''), (string)($dbConfig['password'] ?? ''), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    // Dati iet uz MySQL, bet attēlu faili tiek glabāti privātā servera mapē.
    $store = new MySQLStore($pdo, dirname(__DIR__) . '/storage');
} catch (Throwable $exception) {
    error_log((string)$exception);
    http_response_code(500);
    exit(
        'Neizdevās pieslēgties datubāzei. Pārbaudi config.php datus, vai datubāzes tabulas ir izveidotas, ' .
        'un vai serverī ir iespējots PHP paplašinājums pdo_mysql.'
    );
}

/** Droši izvada tekstu HTML lapā, aizsargājot pret HTML/JavaScript ievietošanu (XSS). */
function e(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Izveido vai atgriež CSRF aizsardzības marķieri šai sesijai. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Pārbauda, vai POST pieprasījumam ir derīgs CSRF marķieris. */
function verify_csrf_token(): void
{
    $sentToken = (string)($_POST['csrf_token'] ?? '');
    $knownToken = (string)($_SESSION['csrf_token'] ?? '');

    if ($sentToken === '' || $knownToken === '' || !hash_equals($knownToken, $sentToken)) {
        throw new ValidationException('Drošības pārbaude neizdevās. Pārlādē lapu un mēģini vēlreiz.');
    }
}

/** Vienkāršs ziņojums pēc pāradresācijas. */
function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function take_flash(): ?array
{
    if (!isset($_SESSION['flash']) || !is_array($_SESSION['flash'])) {
        return null;
    }
    $message = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $message;
}

/** Pāradresācija novērš formas atkārtotu nosūtīšanu, atsvaidzinot lapu. */
function redirect(string $location = 'index.php'): never
{
    header('Location: ' . $location, true, 303);
    exit;
}

/** Atrod pieteikušos lietotāju pēc sesijā glabāta ID. */
function current_user(MySQLStore $store): ?array
{
    $userId = $_SESSION['user_id'] ?? null;
    if (!is_string($userId) || $userId === '') {
        return null;
    }

    foreach ($store->read()['users'] as $user) {
        if (($user['id'] ?? '') === $userId) {
            // Nekad nenododam paroli vai tās jaucējvērtību HTML veidnei.
            return [
                'id' => $user['id'],
                'name' => $user['name'],
                'email' => $user['email'],
                'phone' => $user['phone'] ?? '',
            ];
        }
    }

    // Ja lietotājs vairs nav datubāzē, iztīrām novecojušo sesiju.
    unset($_SESSION['user_id']);
    return null;
}

/** Ja darbībai vajadzīga pieteikšanās, pārtraucam to lietotājam bez sesijas. */
function require_login(MySQLStore $store): array
{
    $user = current_user($store);
    if ($user === null) {
        throw new ValidationException('Lai veiktu šo darbību, vispirms jāpiesakās sistēmā.');
    }
    return $user;
}

/**
 * Pārbauda un saglabā līdz 4 JPEG/PNG/WEBP attēliem.
 * Pēc satura tiek noteikts MIME tips, nosaukumu ģenerē serveris, nevis lietotājs.
 */
function store_uploaded_images(array $files, string $targetDirectory): array
{
    if (!isset($files['name']) || !is_array($files['name'])) {
        return [];
    }

    $allowedMimes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $maxBytes = 5 * 1024 * 1024;
    $maxImages = 4;
    $validFiles = [];

    foreach ($files['name'] as $index => $originalName) {
        $error = (int)($files['error'][$index] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ($error !== UPLOAD_ERR_OK) {
            throw new ValidationException('Attēlu neizdevās augšupielādēt. Pārbaudi faila izmēru un mēģini vēlreiz.');
        }

        $temporaryPath = (string)($files['tmp_name'][$index] ?? '');
        $size = (int)($files['size'][$index] ?? 0);
        if ($temporaryPath === '' || !is_uploaded_file($temporaryPath)) {
            throw new ValidationException('Augšupielādētais fails netika atpazīts kā īsts augšupielādes fails.');
        }
        if ($size <= 0 || $size > $maxBytes) {
            throw new ValidationException('Katrs attēls drīkst būt ne lielāks par 5 MB.');
        }

        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($temporaryPath);
        if (!is_string($mime) || !isset($allowedMimes[$mime])) {
            throw new ValidationException('Atļauti tikai JPEG, PNG un WEBP attēli.');
        }

        $imageInfo = @getimagesize($temporaryPath);
        if ($imageInfo === false || !isset($imageInfo[0], $imageInfo[1])) {
            throw new ValidationException('Fails nav derīgs attēls.');
        }

        $width = (int)$imageInfo[0];
        $height = (int)$imageInfo[1];
        if ($width < 1 || $height < 1 || $width > 8000 || $height > 8000 || $width * $height > 25000000) {
            throw new ValidationException('Attēla izmēri ir pārāk lieli (maksimāli 8000 × 8000 pikseļi).');
        }

        $validFiles[] = ['tmp_name' => $temporaryPath, 'extension' => $allowedMimes[$mime]];
        if (count($validFiles) > $maxImages) {
            throw new ValidationException('Vienam sludinājumam atļauti ne vairāk kā 4 attēli.');
        }
    }

    $savedNames = [];
    try {
        foreach ($validFiles as $file) {
            $safeName = bin2hex(random_bytes(16)) . '.' . $file['extension'];
            $destination = $targetDirectory . DIRECTORY_SEPARATOR . $safeName;
            if (!move_uploaded_file($file['tmp_name'], $destination)) {
                throw new RuntimeException('Neizdevās saglabāt attēlu serverī.');
            }
            $savedNames[] = $safeName;
        }
    } catch (Throwable $exception) {
        foreach ($savedNames as $savedName) {
            @unlink($targetDirectory . DIRECTORY_SEPARATOR . $savedName);
        }
        throw $exception;
    }

    return $savedNames;
}
