<?php
declare(strict_types=1);

/**
 * Validācijas noteikumi vienuviet.
 *
 * Kāpēc atsevišķs fails? Tad pārbaudes nav jāatkārto dažādās lapas vietās,
 * un ir vieglāk saprast, ko programma pieņem un ko noraida.
 */

class ValidationException extends RuntimeException {}

/** Atļautās sludinājumu kategorijas. Formā un servera pusē izmantojam to pašu sarakstu. */
function allowed_categories(): array
{
    return [
        'Elektronika',
        'Apģērbs un apavi',
        'Mājas un dārzs',
        'Sports un atpūta',
        'Grāmatas un mācības',
        'Bērniem',
        'Cits',
    ];
}

/**
 * Atgriež UTF-8 teksta rakstzīmju skaitu.
 * Neizmantojam mbstring, jo tas ne vienmēr ir ieslēgts skolas datoros.
 */
function text_length(string $text): int
{
    $result = preg_match_all('/./us', $text, $matches);

    // Nederīgs UTF-8 teksts tiek uzskatīts par nederīgu, nevis klusām pieņemts.
    if ($result === false) {
        throw new ValidationException('Tekstā ir nederīgas rakstzīmes.');
    }

    return $result;
}

/**
 * Pārveido Latvijas tālruņa numuru vienotā formā +371XXXXXXXX.
 * Pieņemam Latvijas publisko mobilo (2XXXXXXX) un fiksēto (6XXXXXXX) numuru.
 * Atstarpes, iekavas un defises ir atļautas, bet tās netiek saglabātas.
 */
function normalise_latvian_phone(string $phone): string
{
    $phone = trim($phone);
    if ($phone === '') {
        return '';
    }

    // Noņemam tikai vizuālos atdalītājus, nevis patvaļīgus citus simbolus.
    $phone = preg_replace('/[\s()\-]/u', '', $phone) ?? '';

    if (!preg_match('/^(?:\+371)?([26][0-9]{7})$/', $phone, $matches)) {
        throw new ValidationException(
            'Tālrunim jābūt Latvijas mobilajam numuram (2XXXXXXX) vai fiksētajam numuram (6XXXXXXX), piemēram, +371 2XXXXXXX.'
        );
    }

    return '+371' . $matches[1];
}

/**
 * Pārbauda lietotāja vārdu, e-pastu, paroli un tālruni.
 * Atgriež normalizētus datus, ko pēc tam saglabā datu glabātuvē.
 */
function validate_registration(array $input): array
{
    $name = trim((string)($input['name'] ?? ''));
    $email = strtolower(trim((string)($input['email'] ?? '')));
    $password = (string)($input['password'] ?? '');
    $repeatPassword = (string)($input['password_repeat'] ?? '');
    $phone = normalise_latvian_phone((string)($input['phone'] ?? ''));

    $nameLength = text_length($name);
    if ($nameLength < 2 || $nameLength > 40) {
        throw new ValidationException('Vārdam jābūt 2–40 rakstzīmju garam.');
    }

    // filter_var pārbauda e-pasta adreses sintaktisko formu.
    if (strlen($email) > 254 || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        throw new ValidationException('Ievadi derīgu e-pasta adresi.');
    }

    // Lietojam PHP iebūvēto paroles jaukšanu. Šī prototipa parolei jābūt 8–72 baitus garai.
    // 72 baitu robeža nodrošina saderību arī ar PHP vidēs izmantoto bcrypt noklusējumu.
    if (strlen($password) < 8 || strlen($password) > 72) {
        throw new ValidationException('Parolei jābūt vismaz 8 un ne vairāk kā 72 baitu garai.');
    }
    if ($password !== $repeatPassword) {
        throw new ValidationException('Abās paroles ievades ailēs jābūt vienādai parolei.');
    }

    return [
        'name' => $name,
        'email' => $email,
        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        'phone' => $phone,
    ];
}

/**
 * Cenu glabājam centos kā veselā skaitļa vērtību, nevis kā float.
 * Tas novērš tipiskas decimāldaļu noapaļošanas neprecizitātes naudas summām.
 *
 * Ievadei jābūt, piemēram, 12.50 vai 12,50. Publicēšanas formā obligāti ir 2 cipari aiz komata.
 */
function parse_listing_price(string $value): int
{
    $value = trim($value);

    if (!preg_match('/^[0-9]{1,7}[.,][0-9]{2}$/', $value)) {
        throw new ValidationException('Cena jāievada EUR ar tieši diviem cipariem aiz komata, piemēram, 12.50.');
    }

    $parts = preg_split('/[.,]/', $value);
    $euros = (int)$parts[0];
    $cents = (int)$parts[1];
    $totalCents = $euros * 100 + $cents;

    if ($totalCents < 1) {
        throw new ValidationException('Cenai jābūt lielākai par 0,00 EUR.');
    }

    return $totalCents;
}

/**
 * Filtru cenas var atstāt tukšas. Ja ievadītas, pieņemam arī vienu ciparu aiz komata.
 * Nederīgas vērtības tiek pamanītas, nevis izmantotas SQL vai citā vaicājumā.
 */
function parse_optional_filter_price(string $value): ?int
{
    $value = trim($value);
    if ($value === '') {
        return null;
    }

    if (!preg_match('/^[0-9]{1,7}(?:[.,][0-9]{1,2})?$/', $value)) {
        throw new ValidationException('Cenas filtrā ievadi pozitīvu skaitli, piemēram, 10 vai 10.50.');
    }

    $value = str_replace(',', '.', $value);
    $parts = explode('.', $value, 2);
    $whole = (int)$parts[0];
    $fraction = isset($parts[1]) ? str_pad($parts[1], 2, '0') : '00';

    return $whole * 100 + (int)$fraction;
}

/** Validē sludinājuma obligātos laukus. */
function validate_listing(array $input): array
{
    $title = trim((string)($input['title'] ?? ''));
    $description = trim((string)($input['description'] ?? ''));
    $category = trim((string)($input['category'] ?? ''));

    $titleLength = text_length($title);
    if ($titleLength < 5 || $titleLength > 80) {
        throw new ValidationException('Sludinājuma nosaukumam jābūt 5–80 rakstzīmju garam.');
    }

    $descriptionLength = text_length($description);
    if ($descriptionLength < 15 || $descriptionLength > 2000) {
        throw new ValidationException('Aprakstam jābūt 15–2000 rakstzīmju garam.');
    }

    if (!in_array($category, allowed_categories(), true)) {
        throw new ValidationException('Izvēlies kategoriju no piedāvātā saraksta.');
    }

    return [
        'title' => $title,
        'description' => $description,
        'category' => $category,
        'price_cents' => parse_listing_price((string)($input['price'] ?? '')),
    ];
}

/** Parāda cenu ar diviem cipariem aiz komata. */
function format_price(int $cents): string
{
    return number_format($cents / 100, 2, ',', ' ') . ' EUR';
}

/**
 * Tālruņa daļēja maskēšana publiskajā sludinājumā.
 * Pilno numuru HTML lapā neiekļaujam — to saņem tikai pēc autorizēta pieprasījuma.
 */
function mask_phone(string $phone): string
{
    if (strlen($phone) !== 12 || substr($phone, 0, 4) !== '+371') {
        return 'Tālrunis paslēpts';
    }

    $local = substr($phone, 4); // 8 cipari pēc +371
    return '+371 ' . substr($local, 0, 1) . '*** **' . substr($local, -2);
}
