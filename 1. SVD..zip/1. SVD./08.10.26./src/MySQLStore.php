<?php
declare(strict_types=1);

/**
 * MySQL datu glabātuve.
 *
 * Saskarne ir līdzīga sākotnējai JSON glabātuvei, lai pārējais skolas projekts
 * būtu vieglāk saprotams un nebūtu jāpārraksta visi lapas elementi.
 * Reālās tabulas atrodas MySQL datubāzē, bet attēlu faili - storage/uploads mapē.
 *
 * Šim mazajam prototipam update() nolasa datus, pielieto izmaiņu funkciju un
 * ieraksta jaunus lietotājus/sludinājumus vai atjaunina sludinājuma pārdots statusu.
 * Izmaiņas notiek SQL transakcijā, lai saistītie ieraksti tiktu saglabāti kopā.
 */
class MySQLStore
{
    private PDO $pdo;
    private string $uploadsDirectory;

    public function __construct(PDO $pdo, string $storageDirectory)
    {
        $this->pdo = $pdo;
        $this->uploadsDirectory = $storageDirectory . DIRECTORY_SEPARATOR . 'uploads';

        // Saglabājam attēlus ārpus public mapes, lai tos nevarētu pieprasīt kā PHP failus.
        if (!is_dir($this->uploadsDirectory)
            && !mkdir($this->uploadsDirectory, 0775, true)
            && !is_dir($this->uploadsDirectory)) {
            throw new RuntimeException('Neizdevās izveidot attēlu mapi. Pārbaudi mapju rakstīšanas tiesības.');
        }
    }

    /** Atgriež mapi, kur serveris glabā augšupielādētos attēlus. */
    public function uploadsDirectory(): string
    {
        return $this->uploadsDirectory;
    }

    /**
     * Nolasa datus no trim relāciju tabulām un sagatavo masīvu, ko izmanto lapa.
     * Lietotāju paroles tiek nolasītas tikai servera vajadzībām; tās nekad neizvada HTML.
     */
    public function read(): array
    {
        $usersQuery = $this->pdo->query(
            'SELECT id, name, email, password_hash, phone, created_at FROM market_users ORDER BY created_at DESC'
        );
        $users = [];
        foreach ($usersQuery->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $users[] = [
                'id' => (string)$row['id'],
                'name' => (string)$row['name'],
                'email' => (string)$row['email'],
                'password_hash' => (string)$row['password_hash'],
                'phone' => (string)$row['phone'],
                'created_at' => (string)$row['created_at'],
            ];
        }

        $listingsQuery = $this->pdo->query(
            'SELECT id, user_id, title, description, price_cents, category, sold, created_at
             FROM market_listings ORDER BY created_at DESC'
        );
        $listings = [];
        foreach ($listingsQuery->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $listings[] = [
                'id' => (string)$row['id'],
                'user_id' => (string)$row['user_id'],
                'title' => (string)$row['title'],
                'description' => (string)$row['description'],
                'price_cents' => (int)$row['price_cents'],
                'category' => (string)$row['category'],
                'sold' => (bool)$row['sold'],
                'created_at' => (string)$row['created_at'],
                'images' => [],
            ];
        }

        // Ātri atrodam katru sludinājumu, lai attēlus pievienotu pareizajam ierakstam.
        $listingPositions = [];
        foreach ($listings as $position => $listing) {
            $listingPositions[$listing['id']] = $position;
        }

        $imagesQuery = $this->pdo->query(
            'SELECT listing_id, file_name FROM market_listing_images ORDER BY position_no ASC, id ASC'
        );
        foreach ($imagesQuery->fetchAll(PDO::FETCH_ASSOC) as $image) {
            $listingId = (string)$image['listing_id'];
            if (isset($listingPositions[$listingId])) {
                $listings[$listingPositions[$listingId]]['images'][] = (string)$image['file_name'];
            }
        }

        return ['users' => $users, 'listings' => $listings];
    }

    /**
     * Izpilda datu izmaiņas transakcijā.
     * Saglabā jaunus kontus, jaunus sludinājumus un sludinājumu pārdots statusa maiņas.
     * Vaicājumiem tiek izmantoti PDO prepared statements, nevis lietotāja ievade tieši SQL tekstā.
     */
    public function update(callable $callback): mixed
    {
        $this->pdo->beginTransaction();
        try {
            // Saglabājam sākotnējo stāvokli, lai noteiktu, kas funkcijā ir mainījies.
            $before = $this->read();
            $data = $before;
            $result = $callback($data);

            $oldUserIds = [];
            foreach ($before['users'] as $user) {
                $oldUserIds[$user['id']] = true;
            }

            $insertUser = $this->pdo->prepare(
                'INSERT INTO market_users (id, name, email, password_hash, phone, created_at)
                 VALUES (:id, :name, :email, :password_hash, :phone, :created_at)'
            );
            foreach ($data['users'] as $user) {
                if (isset($oldUserIds[$user['id']])) {
                    continue;
                }
                $insertUser->execute([
                    ':id' => $user['id'],
                    ':name' => $user['name'],
                    ':email' => $user['email'],
                    ':password_hash' => $user['password_hash'],
                    ':phone' => $user['phone'] ?? '',
                    ':created_at' => $this->toDatabaseDateTime((string)$user['created_at']),
                ]);
            }

            $oldListingsById = [];
            foreach ($before['listings'] as $listing) {
                $oldListingsById[$listing['id']] = $listing;
            }

            $insertListing = $this->pdo->prepare(
                'INSERT INTO market_listings
                    (id, user_id, title, description, price_cents, category, sold, created_at)
                 VALUES (:id, :user_id, :title, :description, :price_cents, :category, :sold, :created_at)'
            );
            $insertImage = $this->pdo->prepare(
                'INSERT INTO market_listing_images (listing_id, file_name, position_no)
                 VALUES (:listing_id, :file_name, :position_no)'
            );
            $updateSold = $this->pdo->prepare(
                'UPDATE market_listings SET sold = :sold WHERE id = :id AND user_id = :user_id'
            );

            foreach ($data['listings'] as $listing) {
                if (!isset($oldListingsById[$listing['id']])) {
                    $insertListing->execute([
                        ':id' => $listing['id'],
                        ':user_id' => $listing['user_id'],
                        ':title' => $listing['title'],
                        ':description' => $listing['description'],
                        ':price_cents' => $listing['price_cents'],
                        ':category' => $listing['category'],
                        ':sold' => !empty($listing['sold']) ? 1 : 0,
                        ':created_at' => $this->toDatabaseDateTime((string)$listing['created_at']),
                    ]);

                    // Attēlu faili jau atrodas storage/uploads mapē; datubāzē glabājam to nosaukumus.
                    foreach (array_values($listing['images'] ?? []) as $position => $fileName) {
                        $insertImage->execute([
                            ':listing_id' => $listing['id'],
                            ':file_name' => $fileName,
                            ':position_no' => $position,
                        ]);
                    }
                    continue;
                }

                // Pašlaik esošam sludinājumam drīkst mainīt tikai pārdošanas statusu.
                $oldSold = (bool)($oldListingsById[$listing['id']]['sold'] ?? false);
                $newSold = (bool)($listing['sold'] ?? false);
                if ($oldSold !== $newSold) {
                    $updateSold->execute([
                        ':sold' => $newSold ? 1 : 0,
                        ':id' => $listing['id'],
                        ':user_id' => $listing['user_id'],
                    ]);
                    if ($updateSold->rowCount() < 1 && $oldSold !== $newSold) {
                        throw new RuntimeException('Neizdevās atjaunināt sludinājuma statusu.');
                    }
                }
            }

            $this->pdo->commit();
            return $result;
        } catch (Throwable $exception) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $exception;
        }
    }

    /** Pārvērš ISO datumu SQL DATETIME formātā. */
    private function toDatabaseDateTime(string $value): string
    {
        $timestamp = strtotime($value);
        if ($timestamp === false) {
            throw new RuntimeException('Datu laika vērtība nav derīga.');
        }
        return date('Y-m-d H:i:s', $timestamp);
    }
}
