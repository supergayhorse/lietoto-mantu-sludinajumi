
1. Pareizā failu struktūra

Pēc augšupielādes mapēm jābūt šādi:

```
1. SVD./
├── index.php
├── image.php
├── config.php
├── config.example.php
├── assets/
│   ├── app.js
│   └── style.css
├── src/
│   ├── bootstrap.php
│   ├── Validation.php
│   └── MySQLStore.php
├── database/
│   └── schema.sql
├── storage/
│   └── uploads/
└── tests/
```


2. Datubāze

1. Atver savas MySQL datubāzes pārvaldības lapu (piemēram, phpMyAdmin).
2. Izvēlies savu datubāzi, atver SQL sadaļu.
3. Izpildi visu faila `database/schema.sql` saturu.
4. Atver `config.php` un ieraksti hostinga dotās datubāzes vērtības (`host`, `database`, `username`, `password`).
5. Pārliecinies, ka `storage` mapei un `storage/uploads` mapei PHP serverim ir rakstīšanas atļaujas.

Nesūti datubāzes paroli citiem un nepublicē īsto `config.php` ar paroli GitHub.

3. Atver programmu

Atver IS-PROJEKTS-ID, kur atrodas `1. SVD. /index.php`.
