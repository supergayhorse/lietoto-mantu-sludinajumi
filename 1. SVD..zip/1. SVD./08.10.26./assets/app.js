'use strict';

// Pilno tālruņa numuru pieprasām tikai pēc pogas nospiešanas.
// Tas nav jau ielikts HTML lapas pirmkodā, kamēr lietotājs to nav pieprasījis.
document.querySelectorAll('.reveal-phone').forEach((button) => {
    button.addEventListener('click', async () => {
        const listingId = button.dataset.listingId;
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
        const numberContainer = button.closest('.phone-row')?.querySelector('.phone-number');

        if (!listingId || !numberContainer) {
            return;
        }

        button.disabled = true;
        const originalText = button.textContent;
        button.textContent = 'Ielādē...';

        try {
            const formData = new FormData();
            formData.append('action', 'reveal_phone');
            formData.append('listing_id', listingId);
            formData.append('csrf_token', csrfToken);

            const response = await fetch('index.php', {
                method: 'POST',
                body: formData,
                credentials: 'same-origin',
                headers: { 'Accept': 'application/json' }
            });
            const result = await response.json();

            if (!response.ok || !result.ok) {
                throw new Error(result.message || 'Neizdevās parādīt tālruni.');
            }

            // Lietotāja pārlūks šo numuru parāda tikai pēc veiksmīgas servera pārbaudes.
            numberContainer.textContent = result.phone;
            button.textContent = 'Tālrunis parādīts';
            button.disabled = true;
        } catch (error) {
            window.alert(error instanceof Error ? error.message : 'Neizdevās parādīt tālruni.');
            button.disabled = false;
            button.textContent = originalText;
        }
    });
});

// Attēla palielināšanai izmantojam pārlūkā iebūvētu <dialog> elementu.
const imageDialog = document.querySelector('#image-dialog');
const dialogImage = document.querySelector('#dialog-image');
const closeDialogButton = document.querySelector('#close-image-dialog');

document.querySelectorAll('.image-open').forEach((button) => {
    button.addEventListener('click', () => {
        if (!imageDialog || !dialogImage || typeof imageDialog.showModal !== 'function') {
            // Rezerves variants ļoti vecām pārlūkprogrammu versijām.
            if (button.dataset.fullImage) {
                window.open(button.dataset.fullImage, '_blank', 'noopener');
            }
            return;
        }

        dialogImage.src = button.dataset.fullImage || '';
        dialogImage.alt = button.querySelector('img')?.alt || 'Palielināts sludinājuma attēls';
        imageDialog.showModal();
    });
});

closeDialogButton?.addEventListener('click', () => imageDialog?.close());
imageDialog?.addEventListener('click', (event) => {
    // Klikšķis uz tumšā laukuma ārpus attēla aizver logu.
    if (event.target === imageDialog) {
        imageDialog.close();
    }
});
