<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/src/Validation.php';

/** Mazs tests bez papildu testēšanas bibliotēkām. */
function expect_true(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "NEIZDEVĀS: {$message}\n");
        exit(1);
    }
}

function expect_validation_error(callable $callback, string $message): void
{
    try {
        $callback();
    } catch (ValidationException) {
        return;
    }
    fwrite(STDERR, "NEIZDEVĀS (bija jāsaņem validācijas kļūda): {$message}\n");
    exit(1);
}

// Cena tiek pārveidota uz veseliem centiem.
expect_true(parse_listing_price('12.50') === 1250, '12.50 EUR jāpārvērš par 1250 centiem');
expect_true(parse_listing_price('0,01') === 1, '0,01 EUR jāpārvērš par 1 centu');
expect_true(format_price(1234) === '12,34 EUR', 'cena jāparāda ar divām decimāldaļām');
expect_validation_error(fn() => parse_listing_price('0.00'), 'nulles cena nav atļauta');
expect_validation_error(fn() => parse_listing_price('-2.00'), 'negatīva cena nav atļauta');
expect_validation_error(fn() => parse_listing_price('10'), 'cenas ievadē vajag 2 ciparus aiz komata');

// Tālrunis tiek normalizēts ar Latvijas valsts kodu.
expect_true(normalise_latvian_phone('2 123 4567') === '+37121234567', 'mobilais tālrunis jānormalizē');
expect_true(normalise_latvian_phone('+371 61234567') === '+37161234567', 'fiksētais tālrunis jānormalizē');
expect_true(normalise_latvian_phone('') === '', 'tukšs tālrunis nav obligāti jāievada');
expect_validation_error(fn() => normalise_latvian_phone('12345678'), 'nepareizs Latvijas tālruņa prefikss jānoraida');

// Lauku robežas un kategoriju saraksts.
expect_true(in_array('Elektronika', allowed_categories(), true), 'kategoriju sarakstā jābūt Elektronikai');
expect_validation_error(fn() => validate_listing([
    'title' => 'TV',
    'description' => 'Apraksts ir pietiekami garš.',
    'price' => '12.00',
    'category' => 'Elektronika',
]), 'pārāk īss nosaukums jānoraida');
expect_validation_error(fn() => validate_listing([
    'title' => 'Lietots galda dators',
    'description' => 'Šis apraksts ir pietiekami garš.',
    'price' => '12.00',
    'category' => 'Izdomāta kategorija',
]), 'kategorija ārpus atļautā saraksta jānoraida');

// Reģistrācijas pamatpārbaude — paroles atkārtotajam laukam jāsakrīt.
expect_validation_error(fn() => validate_registration([
    'name' => 'Anna',
    'email' => 'anna@example.com',
    'password' => 'TestaParole123',
    'password_repeat' => 'AtšķirīgaParole123',
    'phone' => '',
]), 'nesakrītošas paroles jānoraida');

fwrite(STDOUT, "Visi validācijas testi veiksmīgi.\n");
